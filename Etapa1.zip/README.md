# THE BUG BUSTERS

## Compile, Run and Clean
```
make
make run
make clean
```
Sources can be found under the [src](src) folder. Class files will be generated in the same location as their respective
source file.

## Project Structure
The code has been split into three main parts:
* logic
* state
* xboard

### Logic
The *logic* packet holds the move making code. 

### State
The *state* packet holds the game state model (board, engine modes)

### XBoard
The *xboard* packet holds the implementation of XBoard commands, along with input and output utilities.

## Implementation Details
### Stage 1
At the beginning of each game, the [DummyMoveFinder](src/thebugbusters/pa/project/logic/move/DummyMoveFinder.java) picks
a random pawn and advances it until it either gets blocks or captured by an opponent's piece. Then, the game engine
resigns.

*Note*: capturing opponent's pieces is not implemented.

*Note*: the game engine does not check whether the King is safe before advancing the chosen pawn. If the opponent checks
the game engine, it will attempt to advance the pawn and therefore issue an illegal move. This also leads to another
issue when starting a new game immediately after and reusing the engine. Because it can't tell the game has ended
abruptly, it will notice the pawn chose in the previous game is not where it left it and therefore resigns on its first
move.

## Team Members' Responsibilities
### Stage 1
* Rares-Bogdan Popescu - implementation of XBoard commands, game logic and game state.

* Mihai-Valentin Bita - implementation of XBoard commands, code design.

* Dan-Dumitru Tipa - implementation of XBoard commands and documentation.