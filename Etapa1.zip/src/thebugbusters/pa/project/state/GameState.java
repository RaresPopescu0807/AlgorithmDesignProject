package thebugbusters.pa.project.state;

/**
 * Representation of the chess game state.<p>
 *
 * Holds the player on move, the player assigned to this engine, game modes, time left and the board.<p>
 *
 * The board is represented as a two-dimensional <code>char</code> array.<p>
 */
public abstract class GameState {
    private static boolean xBoardMode;
    private static boolean forceMode;
    private static boolean quitMode;
    private static boolean gameFinished;

    private static Player playerOnMove;
    private static Player playingAs;

    private static long whiteTime;
    private static long blackTime;

    private static char[][] board;

    private GameState() {}

    /**
     * Resets the game state.<p>
     *
     * Sets all flags false, resets the player on move and playing as, resets time to 0 and reinitialize the board for
     * a fresh new game.
     */
    public static void reset() {
        GameState.xBoardMode = false;
        GameState.forceMode = false;
        GameState.quitMode = false;
        GameState.gameFinished = false;

        GameState.playerOnMove = null;
        GameState.playingAs = null;

        GameState.whiteTime = 0;
        GameState.blackTime = 0;

        GameState.board = new char[][] {
                {'r', 'k', 'b', 'q', 'a', 'b', 'k', 'r'},
                {'p', 'p', 'p', 'p', 'p', 'p', 'p', 'p'},
                {' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '},
                {' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '},
                {' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '},
                {' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '},
                {'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P'},
                {'R', 'K', 'B', 'Q', 'A', 'B', 'K', 'R'}
        };
    }

    public static void setForceMode(final boolean forceMode) {
        GameState.forceMode = forceMode;
    }

    public static boolean isInForceMode() {
        return GameState.forceMode;
    }

    public static void setXBoardMode(final boolean xBoardMode) {
        GameState.xBoardMode = xBoardMode;
    }

    public static boolean isInXBoardMode() {
        return GameState.xBoardMode;
    }

    public static void setGameFinished(final boolean gameFinished) {
        GameState.gameFinished = gameFinished;
    }

    public static boolean isGameFinished() {
        return GameState.gameFinished;
    }

    public static Player getPlayerOnMove() {
        return GameState.playerOnMove;
    }

    public static void setPlayerOnMove(final Player playerOnMove) {
        GameState.playerOnMove = playerOnMove;
    }

    public static Player getPlayingAs() {
        return GameState.playingAs;
    }

    public static void setPlayingAs(final Player playingAs) {
        GameState.playingAs = playingAs;
    }

    public static void setQuitMode(final boolean quitMode) {
        GameState.quitMode = quitMode;
    }

    public static long getWhiteTime() {
        return GameState.whiteTime;
    }

    public static void setWhiteTime(final long whiteTime) {
        GameState.whiteTime = whiteTime;
    }

    public static long getBlackTime() {
        return GameState.blackTime;
    }

    public static void setBlackTime(final long blackTime) {
        GameState.blackTime = blackTime;
    }

    public static boolean isInQuitMode() {
        return GameState.quitMode;
    }

    public static char[][] getBoard() {
        return GameState.board;
    }

    /**
     * Executes a move on the board representation.
     *
     * @param move A legal, decoded move.
     * @see Move
     */
    public static void movePieceOnBoard(final Move move) {
        if (move.getPromotion().isPresent()) {
            GameState.board[move.getToLine()][move.getToColumn()] = move.getPromotion().get();
        } else {
            GameState.board[move.getToLine()][move.getToColumn()] =
                    GameState.board[move.getFromLine()][move.getFromColumn()];
        }

        GameState.board[move.getFromLine()][move.getFromColumn()] = ' ';
    }
}
