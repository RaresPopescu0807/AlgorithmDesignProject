package thebugbusters.pa.project.state;

/**
 * Enum representing the player colors.<p>
 *
 * Although they are not technically colors...
 */
public enum Player {
    WHITE,
    BLACK
}
