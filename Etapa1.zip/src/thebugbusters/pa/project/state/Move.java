package thebugbusters.pa.project.state;

import java.util.Optional;

/**
 * Represents a chess move.<p>
 */
public class Move {
    private static final char NO_PROMOTION = '\0';
    private final int fromLine;
    private final int fromColumn;
    private final int toLine;
    private final int toColumn;
    private final char promotion;

    /**
     * Constructs a Move with no pawn promotion.
     *
     * @param fromLine line from which a piece is moved.
     * @param fromColumn column from which a piece is moved.
     * @param toLine line to which a piece is moved.
     * @param toColumn column to which a piece is moved.
     */
    public Move(final int fromLine, final int fromColumn, final int toLine, final int toColumn) {
        this(fromLine, fromColumn, toLine, toColumn, NO_PROMOTION);
    }

    /**
     * Constructs a Move with pawn promotion.
     *
     * @param fromLine line from which a piece is moved.
     * @param fromColumn column from which a piece is moved.
     * @param toLine line to which a piece is moved.
     * @param toColumn column to which a piece is moved.
     * @param promotion symbol of the piece the pawn will be promoted to.
     */
    public Move(final int fromLine, final int fromColumn, final int toLine, final int toColumn, final char promotion) {
        this.fromLine = fromLine;
        this.fromColumn = fromColumn;
        this.toLine = toLine;
        this.toColumn = toColumn;
        this.promotion = promotion;
    }

    public int getFromLine() {
        return this.fromLine;
    }

    public int getFromColumn() {
        return this.fromColumn;
    }

    public int getToLine() {
        return this.toLine;
    }

    public int getToColumn() {
        return this.toColumn;
    }

    public Optional<Character> getPromotion() {
        if (this.promotion != NO_PROMOTION) {
            return Optional.of(this.promotion);
        } else {
            return Optional.empty();
        }
    }
}
