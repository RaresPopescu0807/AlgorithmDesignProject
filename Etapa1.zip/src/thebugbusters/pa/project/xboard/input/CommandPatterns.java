package thebugbusters.pa.project.xboard.input;

import java.util.regex.Pattern;

abstract class CommandPatterns {
    private static final String XBOARD_REGEX        = "^xboard$";
    private static final String PROTOVER_REGEX      = "^protover (\\d)$";
    private static final String NEW_REGEX           = "^new$";
    private static final String FORCE_REGEX         = "^force$";
    private static final String GO_REGEX            = "^go$";
    private static final String WHITE_REGEX         = "^white$";
    private static final String BLACK_REGEX         = "^black$";
    private static final String TIME_REGEX          = "^time (\\d+)$";
    private static final String OTIM_REGEX          = "^otim (\\d+)$";
    private static final String RESULT_REGEX        = "^result (?:(?:\\d-\\d)|\\*) \\{.*\\}$";
    private static final String QUIT_REGEX          = "^quit$";
    private static final String MOVE_REGEX          = "^((?:\\w\\d\\w\\d)(?:\\w)?)$";

    public static final Pattern XBOARD_PATTERN      = Pattern.compile(XBOARD_REGEX);
    public static final Pattern PROTOVER_PATTERN    = Pattern.compile(PROTOVER_REGEX);
    public static final Pattern NEW_PATTERN         = Pattern.compile(NEW_REGEX);
    public static final Pattern FORCE_PATTERN       = Pattern.compile(FORCE_REGEX);
    public static final Pattern GO_PATTERN          = Pattern.compile(GO_REGEX);
    public static final Pattern WHITE_PATTERN       = Pattern.compile(WHITE_REGEX);
    public static final Pattern BLACK_PATTERN       = Pattern.compile(BLACK_REGEX);
    public static final Pattern TIME_PATTERN        = Pattern.compile(TIME_REGEX);
    public static final Pattern OTIM_PATTERN        = Pattern.compile(OTIM_REGEX);
    public static final Pattern RESULT_PATTERN      = Pattern.compile(RESULT_REGEX);
    public static final Pattern QUIT_PATTERN        = Pattern.compile(QUIT_REGEX);
    public static final Pattern MOVE_PATTERN        = Pattern.compile(MOVE_REGEX);

    private CommandPatterns() {}
}
